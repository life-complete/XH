@javax.xml.bind.annotation.XmlSchema(namespace = "http://dhcc.com.cn", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package cn.com.dhcc;

