/**
 * CommonSqlForRecruit3AllPagesResponseDsResultHolder.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package org.tempuri.holders;

public final class CommonSqlForRecruit3AllPagesResponseDsResultHolder implements javax.xml.rpc.holders.Holder {
    public org.tempuri.CommonSqlForRecruit3AllPagesResponseDsResult value;

    public CommonSqlForRecruit3AllPagesResponseDsResultHolder() {
    }

    public CommonSqlForRecruit3AllPagesResponseDsResultHolder(org.tempuri.CommonSqlForRecruit3AllPagesResponseDsResult value) {
        this.value = value;
    }

}
