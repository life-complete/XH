/**
 * Split_Template_UHIDResponseDtHolder.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package org.tempuri.holders;

public final class Split_Template_UHIDResponseDtHolder implements javax.xml.rpc.holders.Holder {
    public org.tempuri.Split_Template_UHIDResponseDt value;

    public Split_Template_UHIDResponseDtHolder() {
    }

    public Split_Template_UHIDResponseDtHolder(org.tempuri.Split_Template_UHIDResponseDt value) {
        this.value = value;
    }

}
