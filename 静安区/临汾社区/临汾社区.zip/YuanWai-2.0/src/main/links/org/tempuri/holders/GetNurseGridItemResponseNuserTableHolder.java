/**
 * GetNurseGridItemResponseNuserTableHolder.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package org.tempuri.holders;

public final class GetNurseGridItemResponseNuserTableHolder implements javax.xml.rpc.holders.Holder {
    public org.tempuri.GetNurseGridItemResponseNuserTable value;

    public GetNurseGridItemResponseNuserTableHolder() {
    }

    public GetNurseGridItemResponseNuserTableHolder(org.tempuri.GetNurseGridItemResponseNuserTable value) {
        this.value = value;
    }

}
