package com.hesicare.hospital.common.jobs;

public class BloodPressureVo {
	
	private Number clsb;
	private Number sbp1;
	private Number dbp1;
	private Number mb1;
	private Number stydjcTimes1;
	private Number bgzmbjcTimes1;
	private String finishTime1;
	private Number sbp2;
	private Number dbp2;
	private Number mb2;
	private Number stydjcTimes2;
	private Number bgzmbjcTimes2;
	private String finishTime2;
	private Number sbp3;
	private Number dbp3;
	private Number mb3;
	private Number stydjcTimes3;
	private Number bgzmbjcTimes3;
	private String finishTime3;
	private String sbpAve;
	private String dbpAve;
	private String mbAve;
	
	public Number getClsb() {
		return clsb;
	}

	public void setClsb(Number clsb) {
		this.clsb = clsb;
	}

	public Number getSbp1() {
		return sbp1;
	}

	public void setSbp1(Number sbp1) {
		this.sbp1 = sbp1;
	}
	
	public Number getDbp1() {
		return dbp1;
	}

	public void setDbp1(Number dbp1) {
		this.dbp1 = dbp1;
	}
	
	public Number getMb1() {
		return mb1;
	}
	
	public void setMb1(Number mb1) {
		this.mb1 = mb1;
	}

	public Number getStydjcTimes1() {
		return stydjcTimes1;
	}
	
	public void setStydjcTimes1(Number stydjcTimes1) {
		this.stydjcTimes1 = stydjcTimes1;
	}
	
	public Number getBgzmbjcTimes1() {
		return bgzmbjcTimes1;
	}

	public void setBgzmbjcTimes1(Number bgzmbjcTimes1) {
		this.bgzmbjcTimes1 = bgzmbjcTimes1;
	}
  
	public String getFinishTime1() {
		return finishTime1;
	}

	public void setFinishTime1(String finishTime1) {
		this.finishTime1 = finishTime1;
	}
	
	public Number getSbp2() {
		return sbp2;
	}

	public void setSbp2(Number sbp2) {
		this.sbp2 = sbp2;
	}
	
	public Number getDbp2() {
		return dbp2;
	}

	public void setDbp2(Number dbp2) {
		this.dbp2 = dbp2;
	}
	
	public Number getMb2() {
		return mb2;
	}
	
	public void setMb2(Number mb2) {
		this.mb2 = mb2;
	}

	public Number getStydjcTimes2() {
		return stydjcTimes2;
	}
	
	public void setStydjcTimes2(Number stydjcTimes2) {
		this.stydjcTimes2 = stydjcTimes2;
	}
	
	public Number getBgzmbjcTimes2() {
		return bgzmbjcTimes2;
	}

	public void setBgzmbjcTimes2(Number bgzmbjcTimes2) {
		this.bgzmbjcTimes2 = bgzmbjcTimes2;
	}
	public String getFinishTime2() {
		return finishTime2;
	}

	public void setFinishTime2(String finishTime2) {
		this.finishTime2 = finishTime2;
	}
	
	public Number getSbp3() {
		return sbp3;
	}

	public void setSbp3(Number sbp3) {
		this.sbp3 = sbp3;
	}
	
	public Number getDbp3() {
		return dbp3;
	}

	public void setDbp3(Number dbp3) {
		this.dbp3 = dbp3;
	}
	
	public Number getMb3() {
		return mb3;
	}
	
	public void setMb3(Number mb3) {
		this.mb3 = mb3;
	}

	public Number getStydjcTimes3() {
		return stydjcTimes3;
	}
	
	public void setStydjcTimes3(Number stydjcTimes3) {
		this.stydjcTimes3 = stydjcTimes3;
	}
	
	public Number getBgzmbjcTimes3() {
		return bgzmbjcTimes3;
	}

	public void setBgzmbjcTimes3(Number bgzmbjcTimes3) {
		this.bgzmbjcTimes3 = bgzmbjcTimes3;
	}
  
	public String getFinishTime3() {
		return finishTime3;
	}

	public void setFinishTime3(String finishTime3) {
		this.finishTime3 = finishTime3;
	}
	
	public String getSbpAve() {
		return sbpAve;
	}

	public void setSbpAve(String sbpAve) {
		this.sbpAve = sbpAve;
	}
	
	public String getDbpAve() {
		return dbpAve;
	}

	public void setDbpAve(String dbpAve) {
		this.dbpAve = dbpAve;
	}
	public String getMbAve() {
		return mbAve;
	}

	public void setMbAve(String mbAve) {
		this.mbAve = mbAve;
	}

	
}
