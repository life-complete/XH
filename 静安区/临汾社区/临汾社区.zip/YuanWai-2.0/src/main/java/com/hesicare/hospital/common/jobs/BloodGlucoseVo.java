package com.hesicare.hospital.common.jobs;

public class BloodGlucoseVo {

	private String measureType;
	private String measureData;


	public String getMeasureType() {
		return measureType;
	}

	public void setMeasureType(String measureType) {
		this.measureType = measureType;
	}

	public String getMeasureData() {
		return measureData;
	}

	public void setMeasureData(String measureData) {
		this.measureData = measureData;
	}


}
