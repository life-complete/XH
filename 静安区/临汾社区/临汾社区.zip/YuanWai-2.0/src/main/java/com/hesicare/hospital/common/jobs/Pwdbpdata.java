package com.hesicare.hospital.common.jobs;

import java.util.List;

public class Pwdbpdata {
	
		private String sfzhm;
		private String xm;
		private String xb;
		private String csDate;
		private String jyklx;
		private String jykh;
		private String clff;
		private String clDate;
		private String meterType;
		private String meterNo;
		private String clysNo;
		private String clysNm;
		private String stationId;
		private String org;
		private String sourceId;
		private List<BloodPressureVo> cljgList;

		public String getSfzhm() {
			return sfzhm;
		}

		public void setSfzhm(String sfzhm) {
			this.sfzhm = sfzhm;
		}
		
		public String getXm() {
			return xm;
		}

		public void setXm(String xm) {
			this.xm = xm;
		}
		
		public String getXb() {
			return xb;
		}

		public void setXb(String xb) {
			this.xb = xb;
		}
		
		public String getCsDate() {
			return csDate;
		}

		public void setCsDate(String csDate) {
			this.csDate = csDate;
		}
		
		public String getJyklx(){
			return jyklx;
		}

		public void setJyklx(String jyklx) {
			this.jyklx = jyklx;
		}
		
		public String getJykh() {
			return jykh;
		}

		public void setJykh(String jykh) {
			this.jykh = jykh;
		}
		
		public String getClff() {
			return clff;
		}

		public void setClff(String clff) {
			this.clff = clff;
		}

		public String getClDate() {
			return clDate;
		}

		public void setClDate(String clDate) {
			this.clDate = clDate;
		}

		public String getMeterType() {
			return meterType;
		}

		public void setMeterType(String meterType) {
			this.meterType = meterType;
		}

		public String getMeterNo() {
			return meterNo;
		}

		public void setMeterNo(String meterNo) {
			this.meterNo = meterNo;
		}

		public String getClysNo() {
			return clysNo;
		}

		public void setClysNo(String clysNo) {
			this.clysNo = clysNo;
		}

		public String getClysNm() {
			return clysNm;
		}

		public void setClysNm(String clysNm) {
			this.clysNm = clysNm;
		}

		public String getStationId() {
			return stationId;
		}

		public void setStationId(String stationId) {
			this.stationId = stationId;
		}
		
		public String getOrg() {
			return org;
		}

		public void setOrg(String org) {
			this.org = org;
		}
		
		public String getSourceId() {
			return sourceId;
		}

		public void setSourceId(String sourceId) {
			this.sourceId = sourceId;
		}
		

		public List<BloodPressureVo> getCljgList() {
			return cljgList;
		}

		public void setCljgList(List<BloodPressureVo> cljgList) {
			this.cljgList = cljgList;
		}



}
