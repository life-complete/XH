package com.hesicare.hospital.health.service;

import com.hesicare.hospital.health.entity.DataBeiTai;

public interface ITripartiteDeviceService {

	void uploadBmi(DataBeiTai dataBmi);

}
